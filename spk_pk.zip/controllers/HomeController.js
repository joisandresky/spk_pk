var myApp = angular.module('myApp');

myApp.controller('HomeController', function($scope, $http){

})